![logo](_media/logo.png)

# Gateway <small>1.0.1</small>

> Pagamentos em Criptomoedas no WooCommerce.

[Started](#instala%C3%A7%C3%A3o)
[GitHub](https://github.com/compralo/woocommerce-plugin/)