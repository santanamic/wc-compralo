- Ponto de partida

  - [Instalação](#instalação)
  - [Requisitos](#requisitos)
  - [Ativando forma de pagamento](#ativando-forma-de-pagamento)
  - [Configuração](#configura%C3%A7%C3%A3o)

- Obtendo credenciais

  - [Acesso a conta](#acesso-a-conta)
  - [Procedimentos](#procedimentos)

- Processo de compra 

  - [Fluxo do checkout](#fluxo-do-checkout)
  - [Cenário típico](#cen%C3%A1rio-t%C3%ADpico)

- Perguntas Frequentes
  
  - [Dúvidas de Negócio](#d%C3%BAvidas-de-neg%C3%B3cio)
 
- Atendimento

  - [Suporte e ajuda](#suporte-e-ajuda)
