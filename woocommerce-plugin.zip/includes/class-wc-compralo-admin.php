<?php
 
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

if ( ! class_exists( 'Wc_Compralo_Admin' ) ) {

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://github.com/compralo/woocommerce-plugin
 * @since      1.0.0
 *
 * @package    wc-compralo
 * @subpackage wc-compralo/includes/
 * @author     AQUARELA - WILLIAN SANTANA <williansantanamic@gmail.com>
 */
	class Wc_Compralo_Admin {
	
	}

}